from .flask_pyoidc import OIDCAuthentication
