Welcome to flask-pyoidc's documentation!
========================================

In addition to this documentation, you may have a look on some 
`example code`_

.. _example code: https://github.com/zamzterz/Flask-pyoidc/tree/master/example

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   configuration
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
